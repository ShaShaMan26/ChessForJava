ChessForJava v0.9
Created by: Cristiano Porretta

*Settings*
- Enter names of player 1 and player 2 to be displayed in game.
- Enter vertical and horizontal offset to better center game on your display (integer value).
	[Vertical offset returns line, horizontal offset adds a space character to left side of printed game]

*Features*
- Full game of Chess, fully playable.
- Does not have special moves such as castling.
- I AM SO SORRY FOR HOW UGLY THE PIECES ARE! I don't know the first thing about GUI development yet and so I had to stick to printing characters in the console.
	I tried to utilize the Unicode Chess piece characters, but was unable to get them formatted correctly.

*Gameplay*
- Move pieces by entering current board position (ex: 'D2'), then entering target position (ex: 'D4').
- Take opposite player's King to win
- Resign by entering 'resign'.
- When Pawn reaches end of board, select promotion by entering icon character (ex: 'q' for Queen).
- Whenever game ends (either from victory or resignation), enter 'y' to play new game or 'n' to quit program.

THIS GAME IS BARELY TESTED SO I'M SORRY IF IT BREAKS